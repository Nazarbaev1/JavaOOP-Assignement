public class Employees {
    private int id;
    private String fname;
    private String lname;
    private int age;
    private String gender;

    public Employees(String genderE, String fname1, String lname1, int ageE, int idE){
        this.gender = genderE;
        this.fname = fname1;
        this.lname = lname1;
        this.age = ageE;
        this.id = idE;
    }
    public String getGender(){
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getFname() {
        return fname;
    }
    public void setName(String name) {
        this.fname = fname;
    }
    public String getLname() {
        return lname;
    }
    public void setLname(String lname) {
        this.lname = lname;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    }

