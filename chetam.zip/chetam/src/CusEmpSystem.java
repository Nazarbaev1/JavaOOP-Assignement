import java.util.ArrayList;

public class CusEmpSystem {
    private ArrayList<Customers>customers;
    private ArrayList<Employees>employees;

    public CusEmpSystem(){
        this.customers = new ArrayList<Customers>();
        this.employees = new ArrayList<Employees>();
    }
    public ArrayList<Customers> getCustomers(){
        return customers;
    }
    public ArrayList<Employees> getEmployees(){
        return employees;
    }

    public void addCustomer(Customers customers){
        this.customers.add(customers);
    }
    public void addEmployees(Employees employees){
        this.employees.add(employees);
    }
}
