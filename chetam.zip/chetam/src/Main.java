import java.util.Scanner;

public class Main {
    public static void main(String [] args){
        CusEmpSystem system = new CusEmpSystem();
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        System.out.println("Hello, you have the following available functions:");
        while(choice != 4){
            System.out.println("1) Add a new customer");
            System.out.println("2) Add a new employee");
            System.out.println("3) Show all customers and employees");
            System.out.println("4) Exit from App");
            choice = sc.nextInt();
            switch(choice){
                case 1:
                    System.out.print("Sex: ");
                    String genderC = sc.next();
                    System.out.print("First Name: ");
                    String fnameSc = sc.next();
                    System.out.print("Last Name: ");
                    String lnameSc = sc.next();
                    System.out.print("Age: ");
                    int ageC = sc.nextInt();
                    System.out.print("Id: ");
                    int id = sc.nextInt();

                    Customers customers = new Customers(genderC, fnameSc, lnameSc, ageC, id);
                    system.addCustomer(customers);
                    break;
                case 2:
                    System.out.print("Sex: ");
                    String genderE = sc.next();
                    System.out.print("First Name: ");
                    String fname1 = sc.next();
                    System.out.print("Last Name: ");
                    String lname1 = sc.next();
                    System.out.print("Age: ");
                    int ageE = sc.nextInt();
                    System.out.print("Id: ");
                    int idE = sc.nextInt();

                    Employees employees = new Employees(genderE, fname1, lname1, ageE, idE);
                    system.addEmployees(employees);
                    break;
                case 3:
                    for(Customers c : system.getCustomers()){
                        System.out.println("Full name " + c.getFname() + " " + c.getLname() + "\n"
                        + " Age is " + c.getAge() + "\n" + "Customer id " + c.getId());
                    }
                    for(Employees e : system.getEmployees()){
                        System.out.println("Full name " +e.getFname() + " " + e.getLname() + "\n"
                                + " Age is " + e.getAge() + "\n" + "Employee id " + e.getId());
                    }
                case 4:
                    System.out.println("Goodbye, see you later!");
                    System.exit(0);
                    break;
            }
        }


    }
}
